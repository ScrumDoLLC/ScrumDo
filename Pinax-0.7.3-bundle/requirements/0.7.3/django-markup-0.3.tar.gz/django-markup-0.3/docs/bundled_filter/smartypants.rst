SmartyPants
===========

- Filter name: ``smartypants``
- Pypi package: ``SmartyPants``

SmartyPants_ is a free web publishing plug-in that easily translates plain ASCII
punctuation characters into “smart” typographic punctuation HTML entities.

.. _SmartyPants: http://daringfireball.net/projects/smartypants/