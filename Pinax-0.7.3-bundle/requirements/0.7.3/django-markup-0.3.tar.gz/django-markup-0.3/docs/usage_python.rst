Usage in Python code
====================

For usage within python code, see the :ref:`formatter` examples.