#!/usr/bin/python
# -*- coding: utf-8 -*-

import doctest
import creole2html

if __name__ == "__main__":
    doctest.testmod(creole2html)
