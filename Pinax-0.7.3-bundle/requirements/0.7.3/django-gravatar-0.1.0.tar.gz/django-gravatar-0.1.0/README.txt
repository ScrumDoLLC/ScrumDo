=======================
django-gravatar
=======================

django-gravatar makes it easy to add gravatar support to your Django 
application through the addition of a template tag.

For installation instructions, read INSTALL.txt.

Visit the google code page at http://django-gravatar.googlecode.com/