from django_openid.demos.consumer.settings import *
