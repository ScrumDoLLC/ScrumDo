from wiki.templatetags.restructuredtext import restructuredtext

restructuredtext('`Available as 1.0 since September, 2007 <http://www.modwsgi.org/>`')
