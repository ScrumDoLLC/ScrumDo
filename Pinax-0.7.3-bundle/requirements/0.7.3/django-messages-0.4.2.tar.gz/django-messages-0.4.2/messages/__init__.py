VERSION = (0, 4, 2)
__version__ = '.'.join(map(str, VERSION))