VERSION = (0, 5, 8)
__version__ = '.'.join(map(str, VERSION))