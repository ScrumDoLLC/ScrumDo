VERSION = (0, 6, 1)
__version__ = '.'.join(map(str, VERSION))