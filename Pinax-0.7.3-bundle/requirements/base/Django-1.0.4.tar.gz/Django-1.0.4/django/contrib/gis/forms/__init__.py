from django.contrib.gis.forms.fields import GeometryField
